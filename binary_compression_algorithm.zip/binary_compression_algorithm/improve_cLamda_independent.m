function [ ri_pi,Lri_npi,R_all_update,I ] = improve_cLamda_independent( Switch,Si1,Lrpi1,S_all_i1,RP_i1_j,rpi1,Lrnpi1,v2i1,Pr,R_all )
%��-1����run,��-2����phrase,��-3����No existence
%   Detailed explanation goes here

%% ��������
% clc
% clear
% Switch=-2;
% Si1=25;
% Lrpi1=8;
% S_all_i1=[1,8,12,14,17,20,22,25,33,36,38,41,49];
% RP_i1_j=[25,41];
% rpi1=3;
% Lrnpi1=2;
% v2i1=0;
% Pr=0.1003;
% R_all=[0.100323370967960,0.100323370967960,0.100323370967960,0,0.100323370967960,0.100323370967960,0,0,0,0.100323370967960];


%%
R_all_update=R_all;
ri_pi=[];
Lri_npi=[];
if Switch==-1
    Ji1_j=find(S_all_i1==RP_i1_j);
    I=Ji1_j;
    if rem(Si1,2)~=0
        if rem(Lrpi1,2)~=0
            if Lrpi1==1
                ri_pi=-3;
                Lri_npi=0;
                Ri1_j=rpi1*Pr;
            else
                ri_pi=rpi1;
                Lri_npi=(Lrpi1-1)/2;
                Ri1_j=rpi1*Pr;
            end
        else
            ri_pi=rpi1;
            Lri_npi=Lrpi1/2;
            Ri1_j=0;
        end
    else
        if rem(Lrpi1,2)~=0
            if Lrpi1==1
                ri_pi=rpi1*(1-Pr)+R_all(1,I-1);
                Lri_npi=1;
                Ri1_j=0;
            else
                ri_pi(1)=rpi1*(1-Pr)+R_all(1,I-1);
                ri_pi(2)=rpi1;
                Lri_npi(1)=1;
                Lri_npi(2)=(Lrpi1-1)/2;
                Ri1_j=0;
            end
        else
            if Lrpi1==2
                ri_pi=rpi1*(1-Pr)+R_all(1,I-1);
                Lri_npi=1;
                Ri1_j=rpi1*Pr;
            else
                ri_pi(1)=rpi1*(1-Pr)+R_all(1,I-1);
                ri_pi(2)=rpi1;
                Lri_npi(1)=1;
                Lri_npi(2)=(Lrpi1-2)/2;
                Ri1_j=rpi1*Pr;
            end
        end
    end
    R_all_update(1,Ji1_j)=Ri1_j;
else
    [~,Ji1_j]=ismember(RP_i1_j,S_all_i1);
    I=Ji1_j(1);
    
    ri_pi=rpi1;
    Lri_npi=Lrnpi1;
    if rem(Si1,2)~=0
        if rem(Lrpi1,2)~=0
            Ri1_j=v2i1*Pr;
        else
            Ri1_j=0;
        end
    else
        if rem(Lrpi1,2)~=0
            Ri1_j=0;
        else
            Ri1_j=v2i1*Pr;
        end
    end
    R_all_update(1,Ji1_j)=Ri1_j;
end

end

