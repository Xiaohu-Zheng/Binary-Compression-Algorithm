function [ v1i,v2i,Lpi ] = improve_di_independent(Si1,Lpi1,v1i1,v2i1,Pr,I,R_all)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
if rem(Si1,2)~=0
    v1i=v1i1*Pr+v2i1*(1-Pr);
    if rem(Lpi1,2)~=0
        if Lpi1==3
            v2i=-3;
            Lpi=1;
        else
            v2i=v2i1;
            Lpi=(Lpi1-3)/2+1;
        end
    else
        if Lpi1==2
            v2i=-3;
            Lpi=1;
        else
            v2i=v2i1;
            Lpi=(Lpi1-2)/2+1;
        end
    end
else
    v1i=R_all(1,I-1)+v1i1*(1-Pr);
    if rem(Lpi1,2)~=0
        v2i=v2i1;
        Lpi=(Lpi1-1)/2+1;
    else
        if Lpi1==2
            v2i=-3;
            Lpi=1;
        else
            v2i=v2i1;
            Lpi=(Lpi1-2)/2+1;
        end
    end
end

end

