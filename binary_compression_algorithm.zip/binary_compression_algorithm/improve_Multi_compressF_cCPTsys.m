function [ cCPT_inter,d0_inter,S_all_i1,RP_i1 ] = improve_Multi_compressF_cCPTsys( n,SDSs )
%����ѹ����ϵͳ��cCPTsys,��-1����run,��-2����phrase
%���룺
%   n:�����
%   State_system:���n+1��״̬����2^n��         %%CPTsys��ϵͳδѹ����CPTsys
%�����
%   cCPT_inter:��ѹ�����State_system
%   d0_inter:����cCPT_inter�Ĵʵ�

%% ��ֵ����
% clc
% clear

% %����
% n=8;
% MCSs={[1,2,3,4],[1,2,3,5],[1,2,3,6],7,8};

%%
p=0;
row=1;
cCPT_inter={};
d0_inter={};
S_all_i1=[];
RP_i1={};

while row<=2^n    
    Lr=1;
    Lp=1;
    if row==2^n
        k=row;
        CPTsys= Multi_F_CPTsys( n,k,SDSs );
        r=CPTsys;
        cCPT_inter{length(cCPT_inter)+1}=[-1,r,1];
        S_all_i1(1,length(S_all_i1)+1)=row;
        RP_i1{1,length(RP_i1)+1}=row;
        row=row+1;
    else
        k=row;
        CPTsys= Multi_F_CPTsys( n,k,SDSs );
        k=row+1;
        CPTsys_1= Multi_F_CPTsys( n,k,SDSs );        
        if CPTsys==CPTsys_1
            r=CPTsys;
            Lr=Lr+1;
            S_all_i1(1,length(S_all_i1)+1)=row;
            RP_i1{1,length(RP_i1)+1}=row;
            row=row+2;
            if row<=2^n
                k=row;
                CPTsys= Multi_F_CPTsys( n,k,SDSs );
                while CPTsys==r    %
                    Lr=Lr+1;
                    row=row+1;
                    k=row;
                    CPTsys= Multi_F_CPTsys( n,k,SDSs );
                    if row>2^n
                        break;
                    end
                end
            end
            cCPT_inter{length(cCPT_inter)+1}=[-1,r,Lr];
        else
            Si_now=row;
            v1=CPTsys;
            v2=CPTsys_1;
            Lp=Lp+1;
            S_all_i1(1,length(S_all_i1)+1)=row;
            row=row+2;
            if row<=2^n
                k=row;
                CPTsys= Multi_F_CPTsys( n,k,SDSs );
                while CPTsys==v2    %
                    Lp=Lp+1;
                    row=row+1;
                    k=row;
                    CPTsys= Multi_F_CPTsys( n,k,SDSs );
                    if row>2^n
                        break;
                    end
                end
            end
            d_inter=[v1,v2,Lp];
            Y=rem(Si_now,2); 
            p1=0;
            if Si_now~=1
                k=Si_now-1;
                R_now= Multi_F_CPTsys( n,k,SDSs );
                for d0j=1:length(d0_inter)
                    if d_inter(1)==d0_inter{d0j}(2)&&d_inter(2)==d0_inter{d0j}(3)&&d_inter(3)==d0_inter{d0j}(4)
                        num_cCPTsys=cell2mat(cCPT_inter);
                        p2=d0_inter{d0j}(1);
                        num1=find(num_cCPTsys==p2);
                        for jc=1:length(num1)
                            if num_cCPTsys(num1(jc)-1)==-2
                                num=ceil(num1(jc)/3);
                                break;
                            end
                        end
                        Si_exist=RP_i1{1,num}(1,1);
                        X=rem(Si_exist,2);
                        if Y==X
                            if X~=0
                                p1=1;
                                break;
                            else
                                k=Si_exist-1;
                                R_exist= Multi_F_CPTsys( n,k,SDSs );
                                if R_now==R_exist
                                    p1=1;
                                    break;
                                end
                            end
                        end
                    end
                end
            end

            if p1==0    %�ж�����һ���µ�phrase
                p=p+1;
                d0_inter{length(d0_inter)+1}=[p,v1,v2,Lp];
                np=1;
                cCPT_inter{length(cCPT_inter)+1}=[-2,p,np];
                RP_i1{1,length(RP_i1)+1}=Si_now;
            elseif p1==1    %�ж����phrase��d0���Ѿ�����
                cCPT_inter{num}(3)=cCPT_inter{num}(3)+1;
                RP_i1{1,num}(1,length(RP_i1{1,num})+1)=Si_now;
            end
        end
    end
end

end

