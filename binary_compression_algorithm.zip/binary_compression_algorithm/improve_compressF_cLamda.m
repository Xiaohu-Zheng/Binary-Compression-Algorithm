function [ cCPT_inter,d0_inter,S_all_i1,RP_i1 ] = improve_compressF_cLamda( n_inter,State_system )
%����ѹ����ϵͳ��cCPTsys,��-1����run,��-2����phrase
%���룺
%   n_inter:�����
%   State_system:���n+1��״̬����2^n��         %%CPTsys��ϵͳδѹ����CPTsys
%�����
%   cCPT_inter:��ѹ�����State_system
%   d0_inter:����cCPT_inter�Ĵʵ�

%% ��ֵ����
% clc
% clear

%����1
% n_inter=4;
% State_system=[0;0;0;1;0;0;1;0;1;0;0;1;0;0;1;1];

%����2
% n_inter=4;
% State_system=[0;0.960596010000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000;0.980100000000000];

%%
p=0;
row=1;
cCPT_inter={};
d0_inter={};
S_all_i1=[];
RP_i1={};

while row<=2^n_inter
    Lr=1;
    Lp=1;
    if row==2^n_inter
        r=State_system(row);
        cCPT_inter{length(cCPT_inter)+1}=[-1,r,1];
        S_all_i1(1,length(S_all_i1)+1)=row;
        RP_i1{1,length(RP_i1)+1}=row;
        row=row+1;
    elseif State_system(row+1)==State_system(row)
        r=State_system(row);
        Lr=Lr+1;
        S_all_i1(1,length(S_all_i1)+1)=row;
        RP_i1{1,length(RP_i1)+1}=row;
        row=row+2;
        if row<=2^n_inter
            while State_system(row)==r    %
                Lr=Lr+1;
                row=row+1;
                if row>2^n_inter
                    break;
                end
            end
        end
        cCPT_inter{length(cCPT_inter)+1}=[-1,r,Lr];
    else
        Si_now=row;
        v1=State_system(row);
        v2=State_system(row+1);
        Lp=Lp+1;
        S_all_i1(1,length(S_all_i1)+1)=row;
        row=row+2;
        if row<=2^n_inter
            while State_system(row)==v2    %
                Lp=Lp+1;
                row=row+1;
                if row>2^n_inter
                    break;
                end
            end
        end
        d_inter=[v1,v2,Lp];
        Y=rem(Si_now,2); 
        p1=0;
        if Si_now~=1
            R_now=State_system(Si_now-1,1);
            for d0j=1:length(d0_inter)
                if d_inter(1)==d0_inter{d0j}(2)&&d_inter(2)==d0_inter{d0j}(3)&&d_inter(3)==d0_inter{d0j}(4)
                    num_cCPTsys=cell2mat(cCPT_inter);
                    p2=d0_inter{d0j}(1);
                    num1=find(num_cCPTsys==p2);
                    for jc=1:length(num1)
                        if num_cCPTsys(num1(jc)-1)==-2
                            num=ceil(num1(jc)/3);
                            break;
                        end
                    end
                    Si_exist=RP_i1{1,num}(1,1);
                    X=rem(Si_exist,2);
                    if Y==X
                        if X~=0
                            p1=1;
                            break;
                        else
                            R_exist=State_system(Si_exist-1,1);
                            if R_now==R_exist
                                p1=1;
                                break;
                            end
                        end
                    end
                end
            end
        end
        
        if p1==0    %�ж�����һ���µ�phrase
            p=p+1;
            d0_inter{length(d0_inter)+1}=[p,v1,v2,Lp];
            np=1;
            cCPT_inter{length(cCPT_inter)+1}=[-2,p,np];
            RP_i1{1,length(RP_i1)+1}=Si_now;
        elseif p1==1    %�ж����phrase��d0���Ѿ�����
            cCPT_inter{num}(3)=cCPT_inter{num}(3)+1;
            RP_i1{1,num}(1,length(RP_i1{1,num})+1)=Si_now;
        end    
    end
end

end

